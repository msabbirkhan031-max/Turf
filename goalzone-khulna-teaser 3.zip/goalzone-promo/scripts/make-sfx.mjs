// Original synthesized SFX — no external audio, fully deterministic, copyright-free.
import { writeFileSync, mkdirSync } from "node:fs";
const SR = 44100;
const OUT = new URL("../public/sfx/", import.meta.url);
mkdirSync(OUT, { recursive: true });

let seed = 12345;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;

const write = (name, data, peak = 0.8) => {
  let mx = 0;
  for (const v of data) mx = Math.max(mx, Math.abs(v));
  const g = mx > 0 ? peak / mx : 1;
  const buf = Buffer.alloc(44 + data.length * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + data.length * 2, 4); buf.write("WAVE", 8);
  buf.write("fmt ", 12); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write("data", 36); buf.writeUInt32LE(data.length * 2, 40);
  data.forEach((v, i) => buf.writeInt16LE(Math.round(Math.max(-1, Math.min(1, v * g)) * 32767), 44 + i * 2));
  writeFileSync(new URL(name, OUT), buf);
};
const N = (s) => Math.floor(s * SR);
const fade = (i, n, a = 0.004) => Math.min(1, i / (a * SR), (n - i) / (0.01 * SR));
const lp = (x, k) => { let y = 0; return x.map((v) => (y += k * (v - y))); };
const bp = (x, f, q) => {
  const w = 2 * Math.sin(Math.PI * f / SR); let lo = 0, b = 0;
  return x.map((v) => { lo += w * b; const hi = v - lo - b / q; b += w * hi; return b; });
};

// POP — short pitched sine drop, fast decay
{ const n = N(0.16), o = new Float32Array(n);
  for (let i = 0; i < n; i++) { const t = i / SR, f = 520 * Math.exp(-t * 14) + 220;
    o[i] = Math.sin(2 * Math.PI * f * t) * Math.exp(-t * 26) * fade(i, n); }
  write("pop.wav", o); }

// CLICK — filtered noise burst
{ const n = N(0.07), raw = Array.from({ length: n }, (_, i) => rnd() * Math.exp(-i / SR * 90));
  const o = Float32Array.from(bp(raw, 2800, 1.6).map((v, i) => v * fade(i, n)));
  write("click.wav", o); }

// TICK — tiny wooden tick
{ const n = N(0.05), o = new Float32Array(n);
  for (let i = 0; i < n; i++) { const t = i / SR; o[i] = Math.sin(2 * Math.PI * 1400 * t) * Math.exp(-t * 120) * fade(i, n); }
  write("tick.wav", o); }

// WHOOSH — band-pass noise sweep, rise then fade (~0.7s)
{ const n = N(0.7), raw = Array.from({ length: n }, () => rnd()); const o = new Float32Array(n);
  let lo = 0, b = 0;
  for (let i = 0; i < n; i++) { const t = i / n, f = 300 + 2600 * Math.pow(t, 1.6);
    const w = 2 * Math.sin(Math.PI * f / SR); lo += w * b; const hi = raw[i] - lo - b / 1.4; b += w * hi;
    const env = Math.sin(Math.PI * Math.pow(t, 0.7)); o[i] = b * env * env * fade(i, n); }
  write("whoosh.wav", o, 0.7); }

// CHIME — soft pluck with gentle overtone, short decay (~0.5s)
{ const n = N(0.5), o = new Float32Array(n);
  for (let i = 0; i < n; i++) { const t = i / SR;
    o[i] = (Math.sin(2 * Math.PI * 880 * t) * Math.exp(-t * 9) + 0.35 * Math.sin(2 * Math.PI * 1320 * t) * Math.exp(-t * 14) + 0.12 * Math.sin(2 * Math.PI * 2640 * t) * Math.exp(-t * 22)) * fade(i, n); }
  write("chime.wav", o); }

// IMPACT — very soft low thump
{ const n = N(0.42), o = new Float32Array(n);
  for (let i = 0; i < n; i++) { const t = i / SR, f = 110 * Math.exp(-t * 9) + 42;
    o[i] = Math.sin(2 * Math.PI * f * t) * Math.exp(-t * 11) * fade(i, n, 0.006); }
  write("impact.wav", Float32Array.from(lp(Array.from(o), 0.5)), 0.85); }
console.log("SFX generated");
