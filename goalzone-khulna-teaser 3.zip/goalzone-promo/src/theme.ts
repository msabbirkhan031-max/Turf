// Single source of truth for every visual constant. No hex colours or easings anywhere else.
import { Easing } from "remotion";
import { loadFont } from "@remotion/google-fonts/HindSiliguri";

const loaded = loadFont("normal", {
  weights: ["500", "600", "700"],
  subsets: ["bengali", "latin"],
});
export const FONT = `${loaded.fontFamily}, "Noto Sans Bengali", sans-serif`;

export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

/** Set to false to preview/render without the voiceover track (SFX stay). */
export const ENABLE_VOICEOVER = true;

// Scheme: "Obsidian & Champagne Gold" — near-black base, muted metallic gold, one restrained emerald accent
export const C = {
  bg: "#0B0A08",
  bgDeep: "#030302",
  bgLift: "#17130C",
  hero: "#C9A24B",
  heroDeep: "#8F6A22",
  heroSoft: "#F1DDAA",
  accent: "#2E9E6B",
  text: "#F6F1E6",
  concrete: "#25251F",
  concreteLight: "#3A3930",
  white: "#FFFFFF",
};

export const withAlpha = (hex: string, a: number) => {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
};

export const W = { regular: 500, semi: 600, bold: 700 } as const;
export const R = { sm: 14, md: 26, lg: 38, pill: 999 } as const;
export const SH = {
  card: `0 30px 80px ${withAlpha(C.bgDeep, 0.65)}, inset 0 1px 0 ${withAlpha(C.text, 0.12)}`,
  glow: `0 0 60px ${withAlpha(C.hero, 0.35)}`,
};
export const SP = { u: 8 } as const;

export const EASE = {
  out: Easing.bezier(0.16, 1, 0.3, 1),
  inOut: Easing.bezier(0.65, 0, 0.35, 1),
  in: Easing.bezier(0.7, 0, 0.84, 0),
  back: Easing.bezier(0.34, 1.56, 0.64, 1),
};

export const SPRING = {
  soft: { damping: 20, stiffness: 90, mass: 0.9 },
  pop: { damping: 12, stiffness: 150, mass: 0.7 },
  snap: { damping: 17, stiffness: 210, mass: 0.6 },
  heavy: { damping: 14, stiffness: 120, mass: 1.2 },
};

export const GRADIENT_HERO = `linear-gradient(100deg, ${C.heroDeep} 0%, ${C.heroSoft} 38%, ${C.hero} 62%, ${C.heroSoft} 100%)`;
