// All timing derives from the Bengali voiceover SRT (seconds). Within-cue anchors are
// distributed across each cue's duration in proportion to the spoken words.
export const TOTAL_SEC = 52.3; // SRT ends 51.78s + short logo hold

export const SCENES = {
  concrete: [0, 6.8],
  echo: [6.7, 8.7],
  football: [8.6, 14.6],
  triple: [14.5, 20.6],
  location: [20.5, 26.3],
  arena: [26.2, 29.1],
  logo: [28.9, 32.4],
  surface: [32.3, 38.2],
  pro: [38.0, 44.2],
  next: [44.0, 50.5],
  finale: [50.3, TOTAL_SEC],
} as const;

export const A = {
  // cue 1–2
  skyline: 0.1, concreteWord: 0.35, tired: 2.55, breath: 4.95, freshAir: 5.55,
  name: 6.8,
  // cue 3
  football: 8.62, khulna: 9.8, history: 11.5, place: 13.2,
  // cue 4
  kick: 15.0, tackle: 16.4, goal: 17.9, different: 18.85,
  // cue 5
  tutpara: 20.4, zakaria: 20.95, mapRoute: 20.9, pin: 22.0, soon: 22.8, premium: 25.1,
  // cue 6
  tech: 26.3, arena: 27.6, logo: 28.9, flood: 31.0,
  // cue 7
  surface: 32.35, thrill: 33.4, bestMatches: 36.4, burst: 37.35,
  // cue 8
  playHeading: 38.6, pro: 39.1, lively: 40.9, ready: 42.45,
  // cue 9
  coming: 44.2, craze: 46.0, nextLevel: 47.9, climb: 47.9, summit: 49.4,
  // cue 10
  where: 50.45, soonPill: 51.2,
} as const;

export type SfxKind = "pop" | "click" | "tick" | "whoosh" | "chime" | "impact";
export type SfxEvent = { at: number; k: SfxKind; v: number; r?: number };

// Subtle, sparse — only entries, card reveals, logo, transitions and major emphasis.
export const SFX: SfxEvent[] = [
  { at: 0.12, k: "impact", v: 0.22 },
  { at: 2.55, k: "pop", v: 0.2, r: 0.85 },
  { at: 5.0, k: "whoosh", v: 0.2, r: 1.1 },
  { at: 5.55, k: "pop", v: 0.26, r: 1.15 },
  { at: 6.62, k: "whoosh", v: 0.22 },
  { at: 6.82, k: "pop", v: 0.28, r: 0.9 },
  { at: 7.2, k: "pop", v: 0.2, r: 0.75 },
  { at: 8.6, k: "impact", v: 0.3 },
  { at: 9.78, k: "pop", v: 0.24 },
  { at: 11.5, k: "chime", v: 0.22, r: 0.9 },
  { at: 14.32, k: "whoosh", v: 0.26 },
  { at: 15.0, k: "pop", v: 0.28, r: 1.0 },
  { at: 16.4, k: "pop", v: 0.28, r: 1.1 },
  { at: 17.9, k: "pop", v: 0.28, r: 1.2 },
  { at: 18.85, k: "click", v: 0.26 },
  { at: 20.3, k: "whoosh", v: 0.28 },
  { at: 22.0, k: "impact", v: 0.26 },
  { at: 22.8, k: "click", v: 0.28 },
  { at: 25.1, k: "chime", v: 0.24, r: 1.0 },
  { at: 26.1, k: "whoosh", v: 0.24 },
  { at: 27.6, k: "click", v: 0.26 },
  { at: 28.82, k: "whoosh", v: 0.3, r: 1.15 },
  { at: 28.9, k: "chime", v: 0.34 },
  { at: 28.9, k: "impact", v: 0.26 },
  { at: 31.05, k: "click", v: 0.28 },
  { at: 31.2, k: "click", v: 0.3, r: 1.1 },
  { at: 32.12, k: "whoosh", v: 0.28 },
  { at: 32.35, k: "pop", v: 0.28, r: 1.0 },
  { at: 33.4, k: "pop", v: 0.28, r: 1.1 },
  { at: 36.4, k: "pop", v: 0.28, r: 1.2 },
  { at: 37.35, k: "whoosh", v: 0.26, r: 1.2 },
  { at: 37.9, k: "whoosh", v: 0.26 },
  { at: 39.1, k: "tick", v: 0.3 },
  { at: 40.9, k: "tick", v: 0.3, r: 1.1 },
  { at: 42.45, k: "impact", v: 0.28 },
  { at: 43.95, k: "whoosh", v: 0.26 },
  { at: 44.2, k: "pop", v: 0.28 },
  { at: 46.0, k: "pop", v: 0.26, r: 1.1 },
  { at: 47.9, k: "chime", v: 0.28, r: 1.1 },
  { at: 49.4, k: "chime", v: 0.3, r: 1.3 },
  { at: 50.15, k: "whoosh", v: 0.28 },
  { at: 50.45, k: "chime", v: 0.34, r: 0.95 },
  { at: 50.45, k: "impact", v: 0.28 },
  { at: 51.2, k: "pop", v: 0.24 },
];
