import React, { createContext, useContext } from "react";
import {
  AbsoluteFill, Audio, Img, Sequence, interpolate, random, spring, staticFile,
  useCurrentFrame, useVideoConfig,
} from "remotion";
import { C, EASE, FONT, GRADIENT_HERO, HEIGHT, R, SH, SPRING, W, WIDTH, withAlpha } from "../theme";
import { SFX, SfxKind } from "../timeline";

/* ───────────── time helpers (absolute seconds, scene-aware) ───────────── */
const StartCtx = createContext(0);

export const useT = () => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  return useContext(StartCtx) + f / fps;
};

export const ease = (t: number, at: number, dur: number, e: (x: number) => number = EASE.out) =>
  interpolate(t, [at, at + dur], [0, 1], { easing: e, extrapolateLeft: "clamp", extrapolateRight: "clamp" });

export const useEase = (at: number, dur: number, e: (x: number) => number = EASE.out) => ease(useT(), at, dur, e);

export const useSpr = (at: number, cfg: { damping: number; stiffness: number; mass: number } = SPRING.soft) => {
  const { fps } = useVideoConfig();
  const t = useT();
  return spring({ frame: Math.max(0, Math.round((t - at) * fps)), fps, config: cfg });
};

export const useBreath = (amp = 0.015, period = 3.2, phase = 0) => {
  const t = useT();
  return 1 + Math.sin((t * Math.PI * 2) / period + phase) * amp;
};

const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
export { lerp };

/* ───────────── text base ───────────── */
export const textBase = (size: number, weight: number = W.bold): React.CSSProperties => ({
  fontFamily: FONT,
  fontSize: size,
  fontWeight: weight,
  lineHeight: 1.35,
  letterSpacing: 0, // Bengali conjuncts must never be tracked
  fontKerning: "normal",
  textRendering: "optimizeLegibility",
  fontFeatureSettings: '"liga" 1, "clig" 1',
  color: C.text,
});

/* ───────────── Words: whitespace-split mask reveal (Bengali-safe) ───────────── */
const Word: React.FC<{
  w: string; at: number; size: number; color: string; weight: number;
  grad: boolean; hl: boolean; outAt: number;
}> = ({ w, at, size, color, weight, grad, hl, outAt }) => {
  const p = useSpr(at, SPRING.soft);
  const out = useEase(outAt, 0.3, EASE.in);
  const sweep = useEase(at + 0.45, 0.7, EASE.inOut);
  const vis = Math.min(1, p * 1.8) * (1 - out);
  return (
    <span
      style={{
        position: "relative", display: "inline-block", overflow: "hidden",
        padding: "0.16em 0.07em 0.32em", margin: "-0.16em -0.07em -0.32em",
      }}
    >
      {hl && (
        <span
          style={{
            position: "absolute", left: "0.07em", bottom: "0.2em", height: "0.3em",
            width: `${sweep * 100}%`, background: withAlpha(C.hero, 0.4), borderRadius: 6, opacity: 1 - out,
          }}
        />
      )}
      <span
        style={{
          ...textBase(size, weight), position: "relative", display: "inline-block", whiteSpace: "nowrap",
          transform: `translateY(${(1 - p) * 112 - out * 45}%) scale(${0.94 + 0.06 * Math.min(p, 1)})`,
          opacity: vis,
          ...(grad
            ? { background: GRADIENT_HERO, WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent",
                filter: `drop-shadow(0 6px 26px ${withAlpha(C.hero, 0.38)})` }
            : { color }),
        }}
      >
        {w}
      </span>
    </span>
  );
};

export const Words: React.FC<{
  text: string; at: number; size: number; color?: string; weight?: number; stagger?: number;
  gradWords?: number[]; hlWords?: number[]; outAt?: number; align?: "center" | "left";
  maxWidth?: number; style?: React.CSSProperties;
}> = ({ text, at, size, color = C.text, weight = W.bold, stagger = 5, gradWords = [], hlWords = [], outAt = 9999, align = "center", maxWidth, style }) => {
  const { fps } = useVideoConfig();
  const words = text.split(/\s+/).filter(Boolean);
  return (
    <div
      style={{
        display: "flex", flexWrap: "wrap", columnGap: size * 0.28, rowGap: size * 0.06,
        justifyContent: align === "center" ? "center" : "flex-start", maxWidth, ...style,
      }}
    >
      {words.map((w, i) => (
        <Word key={i} w={w} at={at + (i * stagger) / fps} size={size} color={color} weight={weight}
          grad={gradWords.includes(i)} hl={hlWords.includes(i)} outAt={outAt} />
      ))}
    </div>
  );
};

/* ───────────── Pop: entrance = opacity + translateY + scale ───────────── */
export const Pop: React.FC<{
  at: number; y?: number; from?: number; outAt?: number; cfg?: { damping: number; stiffness: number; mass: number };
  style?: React.CSSProperties; children: React.ReactNode;
}> = ({ at, y = 40, from = 0.88, outAt = 9999, cfg = SPRING.pop, style, children }) => {
  const p = useSpr(at, cfg);
  const out = useEase(outAt, 0.28, EASE.in);
  return (
    <div style={{ ...style, opacity: Math.min(1, p * 2) * (1 - out),
      transform: `translateY(${(1 - p) * y - out * 30}px) scale(${from + (1 - from) * p})` }}>
      {children}
    </div>
  );
};

/* ───────────── Layers: bg mesh → graphics → grade → grain + vignette ───────────── */
const BgMesh: React.FC<{ gx: number; gy: number; tone: "gold" | "green" | "dark" }> = ({ gx, gy, tone }) => {
  const t = useT();
  const dx = Math.sin(t * 0.35) * 6, dy = Math.cos(t * 0.28) * 5;
  const main = tone === "green" ? C.hero : tone === "gold" ? C.hero : C.concreteLight;
  const second = tone === "green" ? C.accent : C.heroDeep;
  return (
    <AbsoluteFill
      style={{
        background: [
          `radial-gradient(1300px 900px at ${gx + dx}% ${gy + dy}%, ${withAlpha(main, tone === "green" ? 0.13 : 0.2)}, transparent 62%)`,
          `radial-gradient(1000px 800px at ${100 - gx - dy}% ${100 - gy + dx}%, ${withAlpha(second, tone === "green" ? 0.08 : 0.12)}, transparent 60%)`,
          `repeating-linear-gradient(90deg, ${withAlpha(C.text, 0.012)} 0px, ${withAlpha(C.text, 0.012)} 120px, transparent 120px, transparent 240px)`,
          `linear-gradient(180deg, ${C.bgLift} 0%, ${C.bg} 55%, ${C.bgDeep} 100%)`,
        ].join(","),
      }}
    />
  );
};

const NOISE =
  "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='300' height='300'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/></filter><rect width='100%' height='100%' filter='url(%23n)' opacity='0.55'/></svg>\")";

const Grain: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        backgroundImage: NOISE, opacity: 0.075, mixBlendMode: "overlay", pointerEvents: "none",
        backgroundPosition: `${Math.floor(random(`gx${f}`) * 300)}px ${Math.floor(random(`gy${f}`) * 300)}px`,
      }}
    />
  );
};

const Vignette: React.FC = () => (
  <AbsoluteFill style={{ background: `radial-gradient(ellipse at center, transparent 52%, ${withAlpha(C.bgDeep, 0.78)} 100%)`, pointerEvents: "none" }} />
);

const Grade: React.FC = () => (
  <AbsoluteFill style={{ background: `linear-gradient(180deg, ${withAlpha(C.bgDeep, 0.3)} 0%, transparent 38%, ${withAlpha(C.bgDeep, 0.38)} 100%)`, pointerEvents: "none" }} />
);

const Frame: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <div style={{ position: "absolute", inset: 34, borderRadius: 30, border: `1.5px solid ${withAlpha(C.hero, 0.28)}` }} />
    <div style={{ position: "absolute", inset: 46, borderRadius: 22, border: `1px solid ${withAlpha(C.hero, 0.1)}` }} />
  </AbsoluteFill>
);

export const Dust: React.FC<{ n?: number; speed?: number }> = ({ n = 26, speed = 18 }) => {
  const t = useT();
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      {Array.from({ length: n }, (_, i) => {
        const size = 2 + random(`ds${i}`) * 4;
        const x = random(`dx${i}`) * WIDTH + Math.sin(t * 0.6 + i) * 18;
        const y = HEIGHT + 20 - ((t * speed * (0.5 + random(`dv${i}`)) + random(`dy${i}`) * HEIGHT) % (HEIGHT + 40));
        const tw = 0.35 + 0.65 * Math.abs(Math.sin(t * 1.4 + i * 1.7));
        return <div key={i} style={{ position: "absolute", left: x, top: y, width: size, height: size, borderRadius: R.pill,
          background: C.heroSoft, opacity: tw * 0.55, boxShadow: `0 0 ${size * 3}px ${withAlpha(C.hero, 0.6)}` }} />;
      })}
    </AbsoluteFill>
  );
};

export const Stage: React.FC<{ tone?: "gold" | "green" | "dark"; gx?: number; gy?: number; dust?: boolean; children: React.ReactNode }> = ({
  tone = "gold", gx = 50, gy = 45, dust = true, children,
}) => (
  <AbsoluteFill>
    <BgMesh gx={gx} gy={gy} tone={tone} />
    {dust && <Dust />}
    <AbsoluteFill>{children}</AbsoluteFill>
    <Grade />
    <Frame />
    <Grain />
    <Vignette />
  </AbsoluteFill>
);

/* ───────────── Scene shell: sequence + soft push-in + fast exit ───────────── */
export const Scene: React.FC<{
  from: number; to: number; tone?: "gold" | "green" | "dark"; gx?: number; gy?: number;
  exit?: boolean; push?: number; dust?: boolean; children: React.ReactNode;
}> = ({ from, to, tone, gx, gy, exit = true, push = 0.045, dust, children }) => {
  const { fps } = useVideoConfig();
  const f0 = Math.round(from * fps);
  const dur = Math.round((to - from) * fps) + 8;
  return (
    <Sequence from={f0} durationInFrames={dur}>
      <StartCtx.Provider value={f0 / fps}>
        <ShellInner dur={dur} tone={tone} gx={gx} gy={gy} exit={exit} push={push} dust={dust}>{children}</ShellInner>
      </StartCtx.Provider>
    </Sequence>
  );
};

const ShellInner: React.FC<{ dur: number; tone?: "gold" | "green" | "dark"; gx?: number; gy?: number; exit: boolean; push: number; dust?: boolean; children: React.ReactNode }> = ({
  dur, tone, gx, gy, exit, push, dust, children,
}) => {
  const f = useCurrentFrame();
  const inn = interpolate(f, [0, 7], [0, 1], { easing: EASE.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const out = exit ? interpolate(f, [dur - 9, dur], [0, 1], { easing: EASE.in, extrapolateLeft: "clamp", extrapolateRight: "clamp" }) : 0;
  const scale = 1 + push * interpolate(f, [0, dur], [0, 1], { easing: EASE.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" }) + out * 0.03;
  return (
    <AbsoluteFill style={{ opacity: inn * (1 - out), transform: `scale(${scale})` }}>
      <Stage tone={tone} gx={gx} gy={gy} dust={dust}>{children}</Stage>
    </AbsoluteFill>
  );
};

/* ───────────── Transition sweep (gold light band) ───────────── */
export const Sweep: React.FC<{ at: number; dir?: 1 | -1 }> = ({ at, dir = 1 }) => {
  const t = useT();
  const p = ease(t, at - 0.14, 0.7, EASE.inOut);
  if (p <= 0 || p >= 1) return null;
  const x = dir === 1 ? lerp(-45, 145, p) : lerp(145, -45, p);
  return (
    <AbsoluteFill style={{ pointerEvents: "none", overflow: "hidden", mixBlendMode: "screen" }}>
      <div style={{ position: "absolute", top: -200, bottom: -200, width: "34%", left: `${x}%`, transform: "skewX(-16deg)",
        background: `linear-gradient(90deg, transparent, ${withAlpha(C.hero, 0.45)}, ${withAlpha(C.heroSoft, 0.85)}, ${withAlpha(C.hero, 0.45)}, transparent)`,
        filter: "blur(10px)" }} />
    </AbsoluteFill>
  );
};

/* ───────────── SFX layer ───────────── */
const FILE: Record<SfxKind, string> = {
  pop: "sfx/pop.wav", click: "sfx/click.wav", tick: "sfx/tick.wav",
  whoosh: "sfx/whoosh.wav", chime: "sfx/chime.wav", impact: "sfx/impact.wav",
};
const LEN: Record<SfxKind, number> = { pop: 0.16, click: 0.07, tick: 0.05, whoosh: 0.7, chime: 0.5, impact: 0.42 };

export const SfxLayer: React.FC = () => {
  const { fps } = useVideoConfig();
  return (
    <>
      {SFX.map((e, i) => (
        <Sequence key={i} from={Math.round(e.at * fps)} durationInFrames={Math.ceil((LEN[e.k] / (e.r ?? 1)) * fps) + 3} layout="none">
          <Audio src={staticFile(FILE[e.k])} volume={e.v} playbackRate={e.r ?? 1} />
        </Sequence>
      ))}
    </>
  );
};

/* ───────────── Glass card ───────────── */
export const Glass: React.FC<{ style?: React.CSSProperties; hot?: number; children?: React.ReactNode }> = ({ style, hot = 0, children }) => (
  <div style={{
    position: "absolute", borderRadius: R.lg, overflow: "hidden",
    background: `linear-gradient(160deg, ${withAlpha(C.text, 0.11)}, ${withAlpha(C.text, 0.035)})`,
    border: `2px solid ${withAlpha(C.hero, 0.18 + 0.4 * hot)}`,
    boxShadow: `${SH.card}${hot > 0 ? `, 0 0 ${60 * hot}px ${withAlpha(C.hero, 0.25 * hot)}` : ""}`,
    ...style,
  }}>{children}</div>
);

/* ───────────── Vector pieces ───────────── */
export const DrawPath: React.FC<{ d: string; p: number; stroke?: string; w?: number; opacity?: number }> = ({ d, p, stroke = C.hero, w = 6, opacity = 1 }) => (
  <path d={d} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p} fill="none" stroke={stroke}
    strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" opacity={opacity} />
);

const pent = (r: number, cx = 0, cy = 0, rot = -90) =>
  Array.from({ length: 5 }, (_, i) => {
    const a = ((rot + i * 72) * Math.PI) / 180;
    return `${(cx + r * Math.cos(a)).toFixed(2)},${(cy + r * Math.sin(a)).toFixed(2)}`;
  }).join(" ");

export const Ball: React.FC<{ size: number; rot?: number; style?: React.CSSProperties }> = ({ size, rot = 0, style }) => (
  <svg width={size} height={size} viewBox="-60 -60 120 120" style={{ overflow: "visible", ...style }}>
    <defs><clipPath id="gz-ball"><circle r="54" /></clipPath></defs>
    <g transform={`rotate(${rot})`}>
      <circle r="54" fill={C.text} />
      <g clipPath="url(#gz-ball)">
        <polygon points={pent(17)} fill={C.bgDeep} />
        {[0, 1, 2, 3, 4].map((i) => {
          const a = ((-90 + i * 72) * Math.PI) / 180;
          const x1 = Math.cos(a) * 17, y1 = Math.sin(a) * 17, x2 = Math.cos(a) * 36, y2 = Math.sin(a) * 36;
          return (
            <g key={i}>
              <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={C.bgDeep} strokeWidth="2.6" />
              <polygon points={pent(15, Math.cos(a) * 50, Math.sin(a) * 50, -90 + i * 72 + 180)} fill={C.bgDeep} />
            </g>
          );
        })}
      </g>
      <circle r="54" fill="none" stroke={C.bgDeep} strokeWidth="2.5" />
    </g>
  </svg>
);

/* Logo (never distorted: only uniform scale via height) */
export const LOGO_AR = 786 / 738;
export const Logo: React.FC<{ height: number; shine?: number; style?: React.CSSProperties }> = ({ height, shine = 0, style }) => {
  const width = height * LOGO_AR;
  return (
    <div style={{ position: "relative", width, height, ...style }}>
      <Img src={staticFile("assets/logo.png")} style={{ width, height, display: "block" }} />
      <div style={{
        position: "absolute", inset: 0,
        WebkitMaskImage: `url(${staticFile("assets/logo.png")})`, maskImage: `url(${staticFile("assets/logo.png")})`,
        WebkitMaskSize: "100% 100%", maskSize: "100% 100%",
        background: `linear-gradient(110deg, transparent 38%, ${withAlpha(C.white, 0.85)} 50%, transparent 62%)`,
        backgroundSize: "300% 100%", backgroundPosition: `${lerp(100, -20, shine)}% 0`, opacity: shine > 0 && shine < 1 ? 0.75 : 0,
      }} />
    </div>
  );
};

/* Rotating light rays + glow behind the logo */
export const Rays: React.FC<{ size: number; opacity?: number }> = ({ size, opacity = 1 }) => {
  const t = useT();
  return (
    <div style={{ position: "absolute", width: size, height: size, left: "50%", top: "50%", marginLeft: -size / 2, marginTop: -size / 2, opacity,
      transform: `rotate(${t * 6}deg)`,
      background: `repeating-conic-gradient(from 0deg, ${withAlpha(C.hero, 0.16)} 0deg 5deg, transparent 5deg 22deg)`,
      WebkitMaskImage: "radial-gradient(circle, black 0%, transparent 68%)", maskImage: "radial-gradient(circle, black 0%, transparent 68%)" }} />
  );
};

/* Confetti / spark burst, deterministic */
export const Burst: React.FC<{ at: number; x: number; y: number; n?: number; power?: number }> = ({ at, x, y, n = 46, power = 1 }) => {
  const t = useT();
  const u = t - at;
  if (u < 0 || u > 2.2) return null;
  const colors = [C.hero, C.heroSoft, C.accent, C.text];
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      {Array.from({ length: n }, (_, i) => {
        const a = random(`ba${i}`) * Math.PI * 2;
        const v = (260 + random(`bv${i}`) * 720) * power;
        const px = x + Math.cos(a) * v * (1 - Math.exp(-u * 3.2)) / 3.2;
        const py = y + Math.sin(a) * v * (1 - Math.exp(-u * 3.2)) / 3.2 + 520 * u * u * 0.5;
        const s = 8 + random(`bs${i}`) * 12;
        return <div key={i} style={{ position: "absolute", left: px, top: py, width: s, height: s * 0.5, background: colors[i % 4],
          opacity: Math.max(0, 1 - u / 2.1), transform: `rotate(${u * (200 + random(`br${i}`) * 500)}deg)`, borderRadius: 2 }} />;
      })}
    </AbsoluteFill>
  );
};

export const Ripple: React.FC<{ at: number; x: number; y: number; color?: string; size?: number; dur?: number; w?: number }> = ({ at, x, y, color = C.accent, size = 1400, dur = 2.2, w = 3 }) => {
  const t = useT();
  const p = ease(t, at, dur, EASE.out);
  if (p <= 0 || p >= 1) return null;
  return <div style={{ position: "absolute", left: x - size / 2, top: y - size / 2, width: size, height: size, borderRadius: R.pill,
    border: `${w}px solid ${withAlpha(color, 0.8)}`, transform: `scale(${p})`, opacity: (1 - p) * 0.9 }} />;
};

export const Star: React.FC<{ size: number; color?: string }> = ({ size, color = C.heroSoft }) => (
  <svg width={size} height={size} viewBox="-50 -50 100 100" style={{ overflow: "visible" }}>
    <polygon fill={color} points={Array.from({ length: 10 }, (_, i) => {
      const r = i % 2 === 0 ? 46 : 19; const a = ((-90 + i * 36) * Math.PI) / 180;
      return `${(Math.cos(a) * r).toFixed(1)},${(Math.sin(a) * r).toFixed(1)}`;
    }).join(" ")} />
  </svg>
);
