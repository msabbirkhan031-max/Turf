import React from "react";
import { AbsoluteFill } from "remotion";
import { A } from "../timeline";
import { C, EASE, GRADIENT_HERO, HEIGHT, R, SPRING, W, WIDTH, withAlpha } from "../theme";
import {
  Ball, Burst, DrawPath, Glass, Logo, Pop, Rays, Ripple, Star, Words, ease, lerp, textBase, useBreath, useEase, useSpr, useT,
} from "../components/fx";

/* ───────── Scene 8 — bento: surface / atmosphere / best matches ───────── */
const BCard: React.FC<{ at: number; x: number; y: number; w: number; h: number; children: React.ReactNode }> = ({ at, x, y, w, h, children }) => {
  const p = useSpr(at, SPRING.pop);
  const hot = useEase(at, 0.6);
  const br = useBreath(0.008, 3.4, x);
  return (
    <div style={{ position: "absolute", left: x, top: y, width: w, height: h, opacity: Math.min(1, p * 2),
      transform: `translateY(${(1 - p) * 60}px) scale(${(0.9 + 0.1 * Math.min(p, 1)) * br})` }}>
      <Glass hot={hot} style={{ inset: 0 }}>{children}</Glass>
    </div>
  );
};

export const SceneSurface: React.FC = () => {
  const t = useT();
  const sheen = ease(t, A.surface + 0.4, 1.6, EASE.inOut);
  return (
    <>
      <BCard at={A.surface} x={90} y={230} w={900} h={560}>
        <div style={{ position: "absolute", left: 50, right: 50, bottom: 36, height: 210, overflow: "hidden", borderRadius: R.md }}>
          <div style={{ position: "absolute", inset: "-60% -30% -10%", transform: "perspective(600px) rotateX(58deg)",
            background: `repeating-linear-gradient(90deg, ${withAlpha(C.accent, 0.5)} 0px, ${withAlpha(C.accent, 0.5)} 70px, ${withAlpha(C.accent, 0.28)} 70px, ${withAlpha(C.accent, 0.28)} 140px)` }} />
          <div style={{ position: "absolute", top: 0, bottom: 0, width: 160, left: `${lerp(-20, 110, sheen)}%`, transform: "skewX(-18deg)",
            background: `linear-gradient(90deg, transparent, ${withAlpha(C.heroSoft, 0.45)}, transparent)` }} />
        </div>
        <div style={{ position: "absolute", left: 50, top: 40 }}>
          <Words text="PREMIUM SURFACE" at={A.surface + 0.05} size={84} align="left" maxWidth={800} gradWords={[0]} stagger={7} />
        </div>
      </BCard>
      <BCard at={A.thrill} x={90} y={830} w={900} h={300}>
        <div style={{ position: "absolute", left: 50, top: 50 }}>
          <Words text="রোমাঞ্চকর পরিবেশ" at={A.thrill + 0.05} size={70} align="left" maxWidth={400} />
        </div>
        <div style={{ position: "absolute", right: 44, bottom: 44, height: 200, display: "flex", alignItems: "flex-end", gap: 12 }}>
          {Array.from({ length: 12 }, (_, i) => {
            const h = 46 + 140 * Math.abs(Math.sin(t * 3.2 + i * 0.7)) * ease(t, A.thrill + 0.3 + i * 0.04, 0.5);
            return <div key={i} style={{ width: 16, height: h, borderRadius: 8, background: i % 3 === 0 ? C.hero : withAlpha(C.heroSoft, 0.55) }} />;
          })}
        </div>
      </BCard>
      <BCard at={A.bestMatches} x={90} y={1170} w={900} h={300}>
        <div style={{ position: "absolute", left: 50, top: 44 }}>
          <Words text="সেরা ম্যাচ" at={A.bestMatches + 0.05} size={92} align="left" gradWords={[1]} />
        </div>
        <div style={{ position: "absolute", right: 60, top: 50, display: "flex", gap: 14, alignItems: "center" }}>
          {[0, 1, 2].map((i) => {
            const s = ease(t, A.bestMatches + 0.4 + i * 0.18, 0.6, EASE.back);
            return <div key={i} style={{ transform: `scale(${s}) translateY(${i === 1 ? -22 : 0}px)` }}><Star size={i === 1 ? 84 : 62} /></div>;
          })}
        </div>
        <div style={{ position: "absolute", left: 50, right: 50, bottom: 46, height: 10, borderRadius: R.pill, background: withAlpha(C.text, 0.1) }}>
          <div style={{ height: "100%", borderRadius: R.pill, background: GRADIENT_HERO, width: `${ease(t, A.bestMatches + 0.3, 1.4, EASE.inOut) * 100}%` }} />
        </div>
      </BCard>
      <Burst at={A.burst} x={WIDTH / 2} y={HEIGHT * 0.55} />
    </>
  );
};

/* ───────── Scene 9 — more professional, more electric, get ready ───────── */
const Meter: React.FC<{ at: number; y: number; label: string; grad: number[] }> = ({ at, y, label, grad }) => {
  const t = useT();
  const p = ease(t, at + 0.15, 1.2, EASE.inOut);
  const out = ease(t, 42.15, 0.3, EASE.in);
  return (
    <div style={{ position: "absolute", left: 90, top: y, width: 900, opacity: 1 - out, transform: `translateY(${-out * 30}px)` }}>
      <Words text={label} at={at} size={78} align="left" gradWords={grad} outAt={42.15} />
      <div style={{ marginTop: 30, height: 38, borderRadius: R.pill, background: withAlpha(C.text, 0.1), border: `2px solid ${withAlpha(C.hero, 0.25)}`, overflow: "hidden" }}>
        <div style={{ width: `${(0.14 + 0.86 * p) * 100}%`, height: "100%", borderRadius: R.pill, background: GRADIENT_HERO, boxShadow: `0 0 40px ${withAlpha(C.hero, 0.5)}` }} />
      </div>
    </div>
  );
};

export const ScenePro: React.FC = () => {
  const t = useT();
  const ring = ease(t, A.ready, 1.0, EASE.inOut);
  const beat = 1 + Math.max(0, Math.sin((t - A.ready) * 6.5)) * 0.04 * ease(t, A.ready + 0.9, 0.3);
  const cx = WIDTH / 2, cy = HEIGHT / 2;
  return (
    <>
      <div style={{ position: "absolute", top: 400, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Words text="খেলা হবে" at={A.playHeading} size={80} color={withAlpha(C.text, 0.7)} outAt={42.15} />
      </div>
      <Meter at={A.pro} y={620} label="আরও PROFESSIONAL" grad={[1]} />
      <Meter at={A.lively} y={920} label="আরও জমজমাট" grad={[1]} />
      <svg width={WIDTH} height={HEIGHT} style={{ position: "absolute", inset: 0, transform: `scale(${beat})`, transformOrigin: "50% 50%" }}>
        <circle cx={cx} cy={cy} r={370} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - ring} fill="none" stroke={C.hero} strokeWidth={8} strokeLinecap="round" transform={`rotate(-90 ${cx} ${cy})`} />
        <circle cx={cx} cy={cy} r={402} fill="none" stroke={withAlpha(C.hero, 0.25 * ring)} strokeWidth={3} />
      </svg>
      <div style={{ position: "absolute", top: cy - 170, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Words text="প্রস্তুতি নিয়ে রাখুন" at={A.ready} size={110} maxWidth={560} gradWords={[0]} stagger={6} />
      </div>
    </>
  );
};

/* ───────── Scene 10 — football craze → next level ───────── */
const STEP_X = (k: number) => 135 + k * 162 + 70;
const STEP_H = (k: number) => 90 + k * 95;
const STEP_BOTTOM = 440;

const Step: React.FC<{ k: number }> = ({ k }) => {
  const p = useSpr(A.coming + 0.35 + k * 0.12, SPRING.pop);
  const h = STEP_H(k);
  return <div style={{ position: "absolute", left: STEP_X(k) - 70, bottom: STEP_BOTTOM, width: 140, height: h * Math.min(p, 1.04), opacity: Math.min(1, p * 4),
    borderRadius: "16px 16px 0 0", background: `linear-gradient(180deg, ${withAlpha(C.hero, k === 4 ? 0.9 : 0.5)}, ${withAlpha(C.hero, 0.12)})`,
    border: `2px solid ${withAlpha(C.heroSoft, 0.5)}` }} />;
};

export const SceneNext: React.FC = () => {
  const t = useT();
  const prog = ease(t, A.climb, 1.5, EASE.inOut) * 4;
  const k = Math.min(3, Math.floor(prog));
  const u = prog >= 4 ? 1 : prog - k;
  const x = prog >= 4 ? STEP_X(4) : lerp(STEP_X(k), STEP_X(k + 1), u);
  const baseY = (j: number) => HEIGHT - STEP_BOTTOM - STEP_H(j) - 46;
  const bobIdle = t < A.climb ? Math.abs(Math.sin(t * 3)) * 16 : 0;
  const y = (prog >= 4 ? baseY(4) : lerp(baseY(k), baseY(k + 1), u) - Math.sin(Math.PI * u) * 130) - bobIdle;
  const appear = useSpr(A.coming + 0.9, SPRING.pop);
  const summit = ease(t, A.summit, 0.8, EASE.out);
  const center: React.CSSProperties = { position: "absolute", left: 0, right: 0, display: "flex", justifyContent: "center" };
  return (
    <>
      <div style={{ ...center, top: 250 }}>
        <Pop at={A.coming - 0.1} outAt={45.8}>
          <Logo height={270} shine={ease(t, A.coming + 0.2, 1.2, EASE.inOut)} />
        </Pop>
      </div>
      <div style={{ ...center, top: 600 }}>
        <Words text="আসছে" at={A.coming} size={180} gradWords={[0]} outAt={45.8} />
      </div>
      <div style={{ ...center, top: 360 }}>
        <Words text="FOOTBALL CRAZE" at={A.craze} size={124} maxWidth={900} hlWords={[1]} outAt={47.75} />
      </div>
      <div style={{ ...center, top: 330 }}>
        <Words text="NEXT LEVEL" at={A.nextLevel} size={172} maxWidth={900} gradWords={[0, 1]} hlWords={[1]} stagger={8} />
      </div>
      {[0, 1, 2, 3, 4].map((j) => <Step key={j} k={j} />)}
      <div style={{ position: "absolute", left: x - 46, top: y - 46, opacity: Math.min(1, appear * 2) }}>
        <Ball size={92} rot={prog * 220} />
      </div>
      <Ripple at={A.summit} x={STEP_X(4)} y={baseY(4) + 46} color={C.hero} size={560} dur={1.4} />
      <div style={{ position: "absolute", left: STEP_X(4) - 40, top: baseY(4) - 170, transform: `scale(${summit}) rotate(${(1 - summit) * -40}deg)`, opacity: summit }}>
        <Star size={80} />
      </div>
      <Burst at={A.summit} x={STEP_X(4)} y={baseY(4)} n={34} power={0.8} />
    </>
  );
};

/* ───────── Scene 11 — finale ───────── */
export const SceneFinale: React.FC = () => {
  const t = useT();
  const p = useSpr(A.where - 0.1, SPRING.heavy);
  const br = useBreath(0.012, 3.2);
  const flash = 1 - ease(t, A.where - 0.1, 0.5, EASE.out);
  return (
    <>
      <div style={{ position: "absolute", left: 0, right: 0, top: 250, height: 760, display: "flex", justifyContent: "center", alignItems: "center", opacity: Math.min(1, p) }}>
        <Rays size={1300} opacity={0.9} />
        <div style={{ transform: `scale(${(0.82 + 0.18 * Math.min(p, 1.05)) * br})` }}>
          <Logo height={640} shine={ease(t, A.where + 0.3, 1.2, EASE.inOut)} />
        </div>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 1040, display: "flex", justifyContent: "center" }}>
        <Words text="WHERE LEGENDS PLAY" at={A.where} size={98} maxWidth={960} gradWords={[1]} hlWords={[1]} stagger={9} />
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 1340, display: "flex", justifyContent: "center" }}>
        <Pop at={A.soonPill} y={24}>
          <div style={{ padding: "10px 40px 18px", borderRadius: R.pill, border: `2px solid ${withAlpha(C.hero, 0.6)}`, background: withAlpha(C.hero, 0.1) }}>
            <span style={{ ...textBase(54, W.semi), color: C.heroSoft }}>খুব শীঘ্রই</span>
          </div>
        </Pop>
      </div>
      <AbsoluteFill style={{ background: `radial-gradient(circle at 50% 38%, ${withAlpha(C.white, 0.8)}, ${withAlpha(C.heroSoft, 0.45)} 40%, transparent 72%)`, opacity: flash, pointerEvents: "none" }} />
    </>
  );
};
