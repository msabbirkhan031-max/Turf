import React, { useMemo } from "react";
import { AbsoluteFill, random } from "remotion";
import { A } from "../timeline";
import { C, EASE, HEIGHT, R, SPRING, W, WIDTH, withAlpha } from "../theme";
import { Ball, Burst, DrawPath, Pop, Ripple, Words, ease, lerp, textBase, useBreath, useEase, useSpr, useT } from "../components/fx";

/* ───────── Scene 1 — concrete city, fatigue → fresh air ───────── */
const Building: React.FC<{ i: number; x: number; w: number; h: number; shade: number }> = ({ i, x, w, h, shade }) => {
  const p = useSpr(A.skyline + i * 0.07, SPRING.heavy);
  const t = useT();
  const cols = Math.max(3, Math.floor(w / 38));
  const rows = Math.floor(h / 48);
  const air = useEase(A.breath, 1.4, EASE.inOut);
  return (
    <div style={{ position: "absolute", left: x, bottom: 0, width: w, height: h, transform: `translateY(${(1 - Math.min(p, 1)) * (h + 40)}px)`,
      background: `linear-gradient(180deg, ${shade > 0.5 ? C.concreteLight : C.concrete}, ${C.concrete})`,
      borderTopLeftRadius: 4, borderTopRightRadius: 4, boxShadow: `inset 0 2px 0 ${withAlpha(C.text, 0.07)}` }}>
      <div style={{ position: "absolute", inset: "26px 18px 0", display: "grid", gridTemplateColumns: `repeat(${cols}, 1fr)`, gap: "16px 14px", alignContent: "start" }}>
        {Array.from({ length: cols * rows }, (_, k) => {
          const lit = random(`w${i}-${k}`) > 0.72;
          const flick = lit && random(`f${i}-${k}`) > 0.8 ? 0.55 + 0.45 * Math.abs(Math.sin(t * 3 + k)) : 1;
          const col = air > 0.2 && random(`g${i}-${k}`) > 0.55 ? C.accent : C.heroSoft;
          return <div key={k} style={{ height: 22, borderRadius: 2, background: lit ? withAlpha(col, 0.55 * flick) : withAlpha(C.bgDeep, 0.45) }} />;
        })}
      </div>
    </div>
  );
};

export const SceneConcrete: React.FC = () => {
  const t = useT();
  const buildings = useMemo(
    () => Array.from({ length: 10 }, (_, i) => ({ i, x: i * 118 - 50, w: 150 + random(`bw${i}`) * 80, h: 560 + random(`bh${i}`) * 560, shade: random(`bs${i}`) })), []);
  const sink = ease(t, A.tired, 3.5, EASE.inOut) * 36;
  const air = useEase(A.breath, 1.5, EASE.out);
  const breath = useBreath(0.03, 2.4);
  return (
    <>
      <AbsoluteFill style={{ transform: `scale(${breath * 0.0 + 1})` }}>
        {buildings.map((b) => <Building key={b.i} {...b} />)}
        <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 260, background: `linear-gradient(0deg, ${C.bgDeep}, transparent)` }} />
        <div style={{ position: "absolute", left: 0, right: 0, top: 0, height: 1100, background: `linear-gradient(180deg, ${withAlpha(C.bgDeep, 0.85)}, transparent)` }} />
      </AbsoluteFill>
      <AbsoluteFill style={{ background: `radial-gradient(900px 700px at 50% 82%, ${withAlpha(C.accent, 0.4 * air)}, transparent 70%)` }} />
      <Ripple at={A.breath} x={WIDTH / 2} y={1400} size={1700} />
      <Ripple at={A.breath + 0.4} x={WIDTH / 2} y={1400} size={1700} />
      <Ripple at={A.breath + 0.8} x={WIDTH / 2} y={1400} size={1700} />
      <div style={{ position: "absolute", top: 330, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Words text="কংক্রিটের ভিড়" at={A.concreteWord} size={112} maxWidth={960} outAt={2.4} />
      </div>
      <div style={{ position: "absolute", top: 400, left: 0, right: 0, display: "flex", justifyContent: "center", transform: `translateY(${sink}px)` }}>
        <Words text="ক্লান্তি" at={A.tired} size={200} color={withAlpha(C.text, 0.72)} outAt={4.75} />
      </div>
      <div style={{ position: "absolute", top: 520, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Words text="তাজা বাতাস" at={A.freshAir} size={140} maxWidth={960} color={C.accent} />
      </div>
    </>
  );
};

/* ───────── Scene 2 — the name echoes ───────── */
const Echo: React.FC<{ i: number }> = ({ i }) => {
  const t = useT();
  const p = ease(t, A.name + 0.05 + i * 0.17, 1.1, EASE.out);
  return (
    <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center",
      transform: `scale(${1 + p * (0.5 + i * 0.22)})`, opacity: p > 0 ? (1 - p) * 0.6 : 0 }}>
      <span style={{ ...textBase(260), color: "transparent", WebkitTextStroke: `3px ${withAlpha(C.hero, 0.9)}` }}>নাম</span>
    </div>
  );
};

export const SceneEcho: React.FC = () => (
  <>
    {[0, 1, 2, 3].map((i) => <Echo key={i} i={i} />)}
    <Ripple at={A.name} x={WIDTH / 2} y={HEIGHT / 2} color={C.hero} size={1400} dur={1.6} />
    <Ripple at={A.name + 0.35} x={WIDTH / 2} y={HEIGHT / 2} color={C.hero} size={1400} dur={1.6} />
    <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <Words text="নাম" at={A.name} size={260} gradWords={[0]} />
    </div>
  </>
);

/* ───────── Scene 3 — FOOTBALL, new history for Khulna ───────── */
export const SceneFootball: React.FC = () => {
  const t = useT();
  const shift = ease(t, 9.7, 0.7, EASE.inOut);
  const pitch = ease(t, 8.7, 2.0, EASE.inOut);
  const roll = ease(t, 8.3, 1.2, EASE.out);
  const bx = lerp(-260, 540, roll);
  const bob = Math.abs(Math.sin(t * 3)) * 18;
  const bxFinal = lerp(bx, 540, shift);
  const by = lerp(1450 - bob, 640, shift);
  const bs = lerp(230, 170, shift);
  const line = ease(t, 11.6, 1.8, EASE.inOut);
  const nodes = [300, 540, 780];
  return (
    <>
      <svg width={WIDTH} height={HEIGHT} style={{ position: "absolute", inset: 0 }}>
        <DrawPath d={`M540 300 V1620`} p={pitch} stroke={withAlpha(C.text, 0.14)} w={4} />
        <circle cx={540} cy={960} r={300} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - pitch} fill="none" stroke={withAlpha(C.text, 0.14)} strokeWidth={4} />
        <DrawPath d={`M140 1290 H940`} p={line} stroke={withAlpha(C.hero, 0.9)} w={6} />
        {nodes.map((x, i) => {
          const s = ease(t, 11.9 + i * 0.5, 0.6, EASE.back);
          const last = i === 2;
          const pulse = last ? 1 + Math.sin(t * 5) * 0.12 : 1;
          return (
            <g key={i} transform={`translate(${x} 1290) scale(${s * pulse})`}>
              {last && <circle r={34} fill={withAlpha(C.hero, 0.25)} />}
              <circle r={last ? 20 : 13} fill={last ? C.hero : C.bg} stroke={C.hero} strokeWidth={5} />
            </g>
          );
        })}
      </svg>
      <div style={{ position: "absolute", left: 0, right: 0, top: 960 - 130 + lerp(0, -540, shift), display: "flex", justifyContent: "center",
        transform: `scale(${lerp(1, 0.5, shift)})` }}>
        <Words text="FOOTBALL" at={A.football} size={160} gradWords={[0]} />
      </div>
      <div style={{ position: "absolute", left: bx > 0 ? bxFinal - bs / 2 : bxFinal - bs / 2, top: by - bs / 2 }}>
        <Ball size={bs} rot={bxFinal * 0.5} />
      </div>
      <div style={{ position: "absolute", top: 880, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Words text="খুলনার ক্রীড়াঙ্গনে" at={A.khulna} size={84} maxWidth={960} outAt={11.3} />
      </div>
      <div style={{ position: "absolute", top: 840, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Words text="নতুন ইতিহাস" at={A.history} size={132} maxWidth={960} gradWords={[1]} hlWords={[1]} />
      </div>
      <Ripple at={13.15} x={780} y={1290} color={C.hero} size={420} dur={1.2} />
    </>
  );
};
