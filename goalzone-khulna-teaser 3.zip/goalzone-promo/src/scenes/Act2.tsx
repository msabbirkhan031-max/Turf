import React from "react";
import { AbsoluteFill } from "remotion";
import { A } from "../timeline";
import { C, EASE, HEIGHT, R, SPRING, W, WIDTH, withAlpha } from "../theme";
import {
  Ball, DrawPath, Glass, Logo, Pop, Rays, Ripple, Words, ease, lerp, textBase, useBreath, useEase, useSpr, useT,
} from "../components/fx";

/* ───────── Scene 4 — kick / tackle / goal ───────── */
const IconKick: React.FC<{ p: number }> = ({ p }) => {
  const u = Math.min(1, Math.max(0, p));
  const x = (1 - u) * (1 - u) * 30 + 2 * (1 - u) * u * 100 + u * u * 170;
  const y = (1 - u) * (1 - u) * 150 + 2 * (1 - u) * u * -10 + u * u * 120;
  return (
    <svg width={300} height={300} viewBox="0 0 200 200" style={{ overflow: "visible" }}>
      <DrawPath d="M20 165 H180" p={u} stroke={withAlpha(C.text, 0.3)} w={4} />
      <DrawPath d="M30 150 Q100 -10 170 120" p={u} w={5} opacity={0.6} />
      <g transform={`translate(${x - 22} ${y - 22})`}><Ball size={44} rot={u * 540} /></g>
    </svg>
  );
};

const IconTackle: React.FC<{ p: number }> = ({ p }) => {
  const u = Math.min(1, Math.max(0, p));
  return (
    <svg width={300} height={300} viewBox="0 0 200 200" style={{ overflow: "visible" }}>
      <DrawPath d="M20 165 H180" p={u} stroke={withAlpha(C.text, 0.3)} w={4} />
      <DrawPath d="M25 55 L88 108" p={Math.min(1, u * 1.6)} w={9} />
      <DrawPath d="M175 55 L112 108" p={Math.min(1, u * 1.6)} w={9} />
      {[[100, 70, 100, 38], [70, 85, 48, 62], [130, 85, 152, 62], [100, 135, 100, 160]].map(([x1, y1, x2, y2], i) => (
        <DrawPath key={i} d={`M${x1} ${y1} L${x2} ${y2}`} p={Math.max(0, (u - 0.6) * 2.5)} stroke={C.heroSoft} w={5} />
      ))}
      <circle cx={100} cy={112} r={9 * Math.min(1, Math.max(0, (u - 0.5) * 2))} fill={C.hero} />
    </svg>
  );
};

const IconGoal: React.FC<{ p: number }> = ({ p }) => {
  const u = Math.min(1, Math.max(0, p));
  const net = Math.max(0, (u - 0.25) / 0.75);
  return (
    <svg width={300} height={300} viewBox="0 0 200 200" style={{ overflow: "visible" }}>
      {[60, 80, 100, 120, 140].map((x) => <DrawPath key={x} d={`M${x} 70 V160`} p={net} stroke={withAlpha(C.text, 0.4)} w={2.5} />)}
      {[95, 120, 145].map((y) => <DrawPath key={y} d={`M30 ${y} H170`} p={net} stroke={withAlpha(C.text, 0.4)} w={2.5} />)}
      <DrawPath d="M30 165 V70 H170 V165" p={Math.min(1, u * 1.5)} w={9} />
      <g transform={`translate(${lerp(40, 108, u) - 20} ${lerp(30, 118, u) - 20}) `}><Ball size={40} rot={u * 360} /></g>
    </svg>
  );
};

const KCard: React.FC<{ at: number; y: number; label: string; Icon: React.FC<{ p: number }>; side: 1 | -1 }> = ({ at, y, label, Icon, side }) => {
  const p = useSpr(at, SPRING.pop);
  const draw = useEase(at + 0.1, 1.0, EASE.inOut);
  const hot = useEase(at, 0.6);
  const br = useBreath(0.01, 3, y);
  return (
    <div style={{ position: "absolute", left: 90, top: y, width: 900, height: 310, opacity: Math.min(1, p * 2),
      transform: `translateX(${(1 - p) * 90 * side}px) scale(${(0.9 + 0.1 * Math.min(p, 1)) * br})` }}>
      <Glass hot={hot} style={{ inset: 0 }}>
        <div style={{ position: "absolute", top: 5, left: 40 }}><Icon p={draw} /></div>
        <div style={{ position: "absolute", left: 400, right: 40, top: 0, bottom: 0, display: "flex", alignItems: "center", ...textBase(104), letterSpacing: "0.03em" }}>{label}</div>
      </Glass>
    </div>
  );
};

export const SceneTriple: React.FC = () => (
  <>
    <KCard at={A.kick} y={230} label="KICK" Icon={IconKick} side={-1} />
    <KCard at={A.tackle} y={570} label="TACKLE" Icon={IconTackle} side={1} />
    <KCard at={A.goal} y={910} label="GOAL" Icon={IconGoal} side={-1} />
    <div style={{ position: "absolute", top: 1290, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
      <Words text="ভিন্ন এক অভিজ্ঞতা" at={A.different} size={88} maxWidth={960} gradWords={[2]} hlWords={[2]} />
    </div>
  </>
);

/* ───────── Scene 5 — Tutpara Zakaria Road ───────── */
export const SceneLocation: React.FC = () => {
  const t = useT();
  const roads = ease(t, 20.6, 1.6, EASE.inOut);
  const route = ease(t, A.mapRoute, 1.2, EASE.inOut);
  const drop = useSpr(A.pin, SPRING.heavy);
  const glow = 0.5 + 0.5 * Math.sin(t * 4);
  const premiumP = ease(t, A.premium, 0.8);
  return (
    <>
      <div style={{ position: "absolute", left: 90, top: 800, width: 900, height: 700 }}>
        <Glass hot={premiumP} style={{ inset: 0 }}>
          <svg width={900} height={700} viewBox="0 0 800 622">
            {[100, 240, 380, 520].map((y, i) => <DrawPath key={y} d={`M0 ${y} H800`} p={Math.min(1, roads * (1 + i * 0.1))} stroke={withAlpha(C.text, 0.12)} w={3} />)}
            {[150, 340, 520, 690].map((x, i) => <DrawPath key={x} d={`M${x} 0 V622`} p={Math.min(1, roads * (1 + i * 0.1))} stroke={withAlpha(C.text, 0.12)} w={3} />)}
            <DrawPath d="M0 570 L800 90" p={roads} stroke={withAlpha(C.text, 0.2)} w={12} />
            <DrawPath d="M60 590 C220 570 300 430 420 390 S520 310 540 262" p={route} w={9} />
            <ellipse cx={540} cy={266} rx={46 + glow * 14} ry={14 + glow * 4} fill={withAlpha(C.accent, 0.35)} opacity={Math.min(1, drop)} />
            <g transform={`translate(540 ${266 - (1 - Math.min(drop, 1.15)) * 330})`} opacity={Math.min(1, drop * 3)}>
              <path d="M0 0 C-26 -34 -40 -52 -40 -78 a40 40 0 1 1 80 0 C40 -52 26 -34 0 0 Z" fill={C.hero} />
              <circle cx={0} cy={-78} r={15} fill={C.bgDeep} />
            </g>
          </svg>
        </Glass>
      </div>
      <Ripple at={A.pin + 0.15} x={697} y={1099} color={C.accent} size={560} dur={1.6} />
      <div style={{ position: "absolute", left: 90, top: 270 }}>
        <Words text="টুটপাড়া" at={A.tutpara} size={130} align="left" outAt={24.85} />
        <Words text="জাকারিয়া রোড" at={A.zakaria} size={130} align="left" maxWidth={900} gradWords={[1]} outAt={24.85} />
      </div>
      <div style={{ position: "absolute", left: 90, top: 640 }}>
        <Pop at={A.soon} outAt={24.85} y={30}>
          <div style={{ display: "inline-block", padding: "14px 36px 22px", borderRadius: R.pill, border: `2px solid ${withAlpha(C.hero, 0.6)}`, background: withAlpha(C.hero, 0.1) }}>
            <Words text="খুব শীঘ্রই উন্মোচিত" at={A.soon + 0.05} size={54} color={C.heroSoft} outAt={24.85} />
          </div>
        </Pop>
      </div>
      <div style={{ position: "absolute", left: 90, top: 260 }}>
        <Words text="MOST PREMIUM" at={A.premium} size={176} align="left" maxWidth={900} gradWords={[1]} hlWords={[1]} stagger={7} />
      </div>
    </>
  );
};

/* ───────── Scene 6 — tech-advanced sports arena ───────── */
export const SceneArena: React.FC = () => {
  const t = useT();
  const d = ease(t, 26.4, 1.7, EASE.inOut);
  const scan = ease(t, 26.9, 1.7, EASE.inOut);
  const lines: [string, number][] = [
    ["M40 40 H600 V960 H40 Z", 1], ["M40 500 H600", 1.2], ["M190 40 V190 H450 V40", 1.4], ["M190 960 V810 H450 V960", 1.4],
    ["M270 40 V100 H370 V40", 1.5], ["M270 960 V900 H370 V960", 1.5],
  ];
  return (
    <>
      <div style={{ position: "absolute", left: 60, top: -30, width: 960, height: 1500, transformOrigin: "50% 100%", transform: "perspective(1600px) rotateX(58deg)" }}>
        <svg width={960} height={1500} viewBox="0 0 640 1000">
          {Array.from({ length: 10 }, (_, i) => <rect key={i} x={40} y={40 + i * 92} width={560} height={92} fill={i % 2 ? withAlpha(C.accent, 0.1) : withAlpha(C.accent, 0.04)} opacity={d} />)}
          {lines.map(([p, k], i) => <DrawPath key={i} d={p} p={Math.min(1, d * k)} stroke={withAlpha(C.text, 0.85)} w={4} />)}
          <circle cx={320} cy={500} r={95} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - d} fill="none" stroke={withAlpha(C.text, 0.85)} strokeWidth={4} />
          <rect x={40} y={40 + scan * 900 - 6} width={560} height={12} fill={C.accent} opacity={scan > 0 && scan < 1 ? 0.8 : 0} />
          <rect x={40} y={40 + scan * 900 - 120} width={560} height={120} fill={withAlpha(C.accent, 0.18)} opacity={scan > 0 && scan < 1 ? 1 : 0} />
        </svg>
      </div>
      <div style={{ position: "absolute", top: 300, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Words text="TECH-ADVANCED" at={A.tech} size={104} />
      </div>
      <div style={{ position: "absolute", top: 440, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Words text="SPORTS ARENA" at={A.arena} size={104} gradWords={[0, 1]} stagger={7} />
      </div>
    </>
  );
};

/* ───────── Scene 7 — Goal Zone Khulna logo + floodlights ───────── */
export const SceneLogo: React.FC = () => {
  const t = useT();
  const p = useSpr(A.logo, SPRING.heavy);
  const flash = 1 - ease(t, A.logo, 0.55, EASE.out);
  const shine = ease(t, A.logo + 0.5, 1.2, EASE.inOut);
  const lift = ease(t, 30.8, 0.8, EASE.inOut);
  const br = useBreath(0.012, 3.2);
  const on = ease(t, A.flood, 0.5, EASE.out);
  const flick = t < A.flood ? 0 : t < A.flood + 0.08 ? 1 : t < A.flood + 0.16 ? 0.2 : t < A.flood + 0.24 ? 1 : on;
  const h = lerp(720, 620, lift);
  return (
    <>
      <svg width={WIDTH} height={HEIGHT} style={{ position: "absolute", inset: 0 }}>
        <defs>
          <linearGradient id="beamL" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor={C.heroSoft} stopOpacity="0.55" /><stop offset="1" stopColor={C.hero} stopOpacity="0" /></linearGradient>
          <linearGradient id="beamR" x1="1" y1="0" x2="0" y2="1"><stop offset="0" stopColor={C.heroSoft} stopOpacity="0.55" /><stop offset="1" stopColor={C.hero} stopOpacity="0" /></linearGradient>
        </defs>
        <g style={{ filter: "blur(9px)" }} opacity={flick}>
          <polygon points="110,330 900,1550 180,1550" fill="url(#beamL)" />
          <polygon points="970,330 180,1550 900,1550" fill="url(#beamR)" />
        </g>
        {[110, 970].map((x) => (
          <g key={x} opacity={Math.min(1, ease(t, A.flood - 0.4, 0.4))}>
            <line x1={x} y1={330} x2={x} y2={560} stroke={withAlpha(C.text, 0.4)} strokeWidth={6} />
            <rect x={x - 46} y={298} width={92} height={34} rx={6} fill={withAlpha(C.text, 0.18)} stroke={withAlpha(C.text, 0.5)} strokeWidth={3} />
            {[-28, -9, 9, 28].map((dx) => <circle key={dx} cx={x + dx} cy={315} r={6} fill={C.heroSoft} opacity={0.35 + 0.65 * flick} />)}
          </g>
        ))}
      </svg>
      <AbsoluteFill style={{ opacity: Math.min(1, p) }}>
        <div style={{ position: "absolute", left: 0, right: 0, top: lerp(850, 760, lift) - 450, display: "flex", justifyContent: "center", height: 900, alignItems: "center" }}>
          <Rays size={1500} opacity={0.9} />
          <div style={{ transform: `scale(${(0.8 + 0.2 * Math.min(p, 1.05)) * br}) translateY(${(1 - Math.min(p, 1)) * 40}px)` }}>
            <Logo height={h} shine={shine} />
          </div>
        </div>
      </AbsoluteFill>
      <div style={{ position: "absolute", left: 0, right: 0, top: 1240, display: "flex", justifyContent: "center" }}>
        <Words text="বিশ্বমানের FLOODLIGHT" at={A.flood - 0.1} size={100} maxWidth={900} gradWords={[1]} stagger={7} />
      </div>
      <AbsoluteFill style={{ background: `radial-gradient(circle at 50% 44%, ${withAlpha(C.white, 0.9)}, ${withAlpha(C.heroSoft, 0.5)} 40%, transparent 72%)`, opacity: flash, pointerEvents: "none" }} />
    </>
  );
};
