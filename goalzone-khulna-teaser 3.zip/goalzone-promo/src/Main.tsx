import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { C, ENABLE_VOICEOVER } from "./theme";
import { SCENES as S } from "./timeline";
import { Scene, SfxLayer, Sweep } from "./components/fx";
import { SceneConcrete, SceneEcho, SceneFootball } from "./scenes/Act1";
import { SceneArena, SceneLocation, SceneLogo, SceneTriple } from "./scenes/Act2";
import { SceneFinale, SceneNext, ScenePro, SceneSurface } from "./scenes/Act3";

export const Main: React.FC = () => (
  <AbsoluteFill style={{ backgroundColor: C.bgDeep }}>
    <Scene from={S.concrete[0]} to={S.concrete[1]} tone="dark" gy={70}><SceneConcrete /></Scene>
    <Scene from={S.echo[0]} to={S.echo[1]} tone="gold" push={0.03}><SceneEcho /></Scene>
    <Scene from={S.football[0]} to={S.football[1]} tone="green" gy={60}><SceneFootball /></Scene>
    <Scene from={S.triple[0]} to={S.triple[1]} tone="gold"><SceneTriple /></Scene>
    <Scene from={S.location[0]} to={S.location[1]} tone="green" gx={65}><SceneLocation /></Scene>
    <Scene from={S.arena[0]} to={S.arena[1]} tone="green" gy={70} push={0.03}><SceneArena /></Scene>
    <Scene from={S.logo[0]} to={S.logo[1]} tone="gold" gy={45} push={0.03}><SceneLogo /></Scene>
    <Scene from={S.surface[0]} to={S.surface[1]} tone="green"><SceneSurface /></Scene>
    <Scene from={S.pro[0]} to={S.pro[1]} tone="gold"><ScenePro /></Scene>
    <Scene from={S.next[0]} to={S.next[1]} tone="green" gx={35}><SceneNext /></Scene>
    <Scene from={S.finale[0]} to={S.finale[1]} tone="gold" exit={false} push={0.02}><SceneFinale /></Scene>
    {[14.4, 20.4, 32.2, 38.0, 50.2].map((a, i) => <Sweep key={a} at={a} dir={i % 2 ? -1 : 1} />)}
    <SfxLayer />
    {ENABLE_VOICEOVER && <Audio src={staticFile("voiceover.mp3")} />}
  </AbsoluteFill>
);
